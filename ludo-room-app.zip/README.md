# Ludo Room App

A simple React + Firebase app to create and manage Ludo game rooms.